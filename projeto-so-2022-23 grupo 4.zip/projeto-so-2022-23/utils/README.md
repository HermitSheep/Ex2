# projeto-so-2022-23

Código fornecido para o segundo exercício do projeto de Sistemas Operativos do ano letivo 2022-2023.

Consultar o [enunciado do projeto](https://github.com/tecnico-so/enunciado-proj-so-2022-23).


(muito obrigado)